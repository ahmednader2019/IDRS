<?php $__env->startSection('content'); ?>

    <h2 style="text-align: center; color: blue;">  Attachements </h2>
    <div>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
    <div class="row">
        <div class="col-xl-12 mb-30">
          <div class="card card-statistics h-100">
            <div class="card-body">
        <div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
    <form method="POST" action="<?php echo e(URL('save')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom: 20px;">
            <label for="filename1" style="font-weight: bold; font-size: 18px;">Personal Photo:</label>
            <input type="file" name="filename1" id="filename1" style="margin-left: 10px;">
          </div>
          <div style="margin-bottom: 20px;">
            <label for="filename2" style="font-weight: bold; font-size: 18px;">Driver License:</label>
            <input type="file" name="filename2" id="filename2" style="margin-left: 10px;">
          </div>
          <div style="margin-bottom: 20px;">
            <label for="filename3" style="font-weight: bold; font-size: 18px;">Car License:</label>
            <input type="file" name="filename3" id="filename3" style="margin-left: 10px;">
          </div>
        <button type="submit" class="btn btn-primary" style="font-size: 15px; padding: 12px 26px; display: block; margin: 0 ; float: right;">Submit</button>

    </form>

 <a href="<?php echo e(URL('step3')); ?>">
    <button type="submit" class="btn btn-primary" style="font-size: 15px; padding: 12px 26px; display: block; margin: 0 ; float: left;">Previous</button>
</a>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php\IDRS\resources\views/driver/addDriver4.blade.php ENDPATH**/ ?>