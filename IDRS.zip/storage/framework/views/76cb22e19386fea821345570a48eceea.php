<?php $__env->startSection('title'); ?>
Show Medical Infs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger"  role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

  <div class="row">
    <div class="col-xl-12 mb-30">
      <div class="card card-statistics h-100">
        <div class="card-body">
         <div class="d-block d-md-flex justify-content-between">
            <div class="d-block">
              <h5 class="card-title pb-0 border-0"> Medical Informations </h5>
            </div>
            <div class="d-block d-md-flex clearfix sm-mt-20">
               <div class="clearfix">
                 <div class="box">
                  <select class="fancyselect sm-mb-20 mr-20">
                    <option value="1">Some option</option>
                    <option value="2">Another option</option>
                    <option value="3">A option</option>
                    <option value="4">Potato</option>
                  </select>
                </div>
              </div>
               <div class="widget-search ml-0 clearfix">
                <i class="fa fa-search"></i>
                <input type="search" class="form-control" placeholder="Search....">
              </div>
             </div>
           </div>
           <div class="table-responsive mt-15">
            <table class="table center-aligned-table mb-0">
              <thead>
                <tr class="text-dark">
                    <th> Driver ID</th>
                    <th> Driver Name </th>
                    <th>Pressure </th>
                    <th>Diabetes </th>
                    <th>blood type</th>
                    <th>Diseases</th>
                    <th>Diseases-details</th>
                    <th>Surgeries</th>
                    <th>Surgeries-details</th>
                    <th> process </th>
                    <th></th>
                    <th></th>
                </tr>
              </thead>
              <?php $__currentLoopData = $health; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $health): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tbody>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($health->driver->name); ?></td>
                    <td><?php echo e($health->pressure); ?></td>
                    <td><?php echo e($health->diabetes); ?></td>
                    <td><?php echo e($health->blood); ?></td>
                    <td><?php echo e($health->diseases); ?></td>
                    <td><?php echo e($health->diseases_details); ?></td>
                    <td> <?php echo e($health->surgeries); ?></td>
                    <td><?php echo e($health->surgeries_details); ?></td>
                  

                     <td><a href="<?php echo e(url('Details')); ?>/<?php echo e($health->id); ?>" class="btn btn-outline-success btn-md">More Info  <i class="fa fa-user"></i></a></td>
                      <td><a href="<?php echo e(url('edit_health')); ?>/<?php echo e($health->id); ?>" class="btn btn-outline-warning btn-md">Edit  <i class="fa fa-pencil-square-o"></i></a></td>
                     
                      <td><button type="button" class="btn btn-outline-danger btn-md" data-toggle="modal" data-target="#delete_driver<?php echo e($id = $health->id); ?>">
                        Delete  <i class="fa fa-trash-o"></i>

                       </button></td>
                     </tr>
                     <?php echo $__env->make('driver.delete_driver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </tbody>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php\IDRS\resources\views/Driver/ShowHealthCondition.blade.php ENDPATH**/ ?>