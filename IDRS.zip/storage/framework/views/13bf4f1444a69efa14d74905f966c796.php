<?php $__env->startSection('content'); ?>

    <h2 style="text-align: center; color: blue;"> Health Information  </h2>
    <div>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
       <?php echo e($diabetes = $health->diabetes); ?>

       <?php echo e($pressure = $health->pressure); ?>

       <?php echo e($diseases = $health->diseases); ?>

       <?php echo e($surgeries = $health->surgeries); ?>

    <form  action="<?php echo e(URL('update_health')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <input type="hidden" name="id" value="<?php echo e($health->id); ?>">

            <div class="form-group col-md-6">
                <label for="inputEmail4"> Do you have a  pressure problem ?</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="pressure" id="exampleRadios1" value="yes"
                    <?php if($pressure == 'yes'): ?>
                    checked
                   <?php endif; ?>>
                    <label class="form-check-label" for="pressure">
                      Yes
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="pressure" id="exampleRadios2" value="no"
                        <?php if($pressure == 'no'): ?>
                        checked
                        <?php endif; ?>>
                    <label class="form-check-label" for="pressure">
                      No
                    </label>
                  </div>
           </div>
           <div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
           <div class="form-group col-md-6">
            <label for="inputEmail4"> Do you have Diabetes ?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="diabetes" id="#exampleRadios1" value="yes"
                <?php if($diabetes == 'yes'): ?>
                    checked
                <?php endif; ?>>
                <label class="form-check-label" for="diabetes">
                   Yes
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="diabetes" id="#exampleRadios2" value="no"
                <?php if($diabetes == 'no'): ?>
                 checked
               <?php endif; ?>>
                <label class="form-check-label" for="diabetes">
                    No
                </label>
              </div>
           </div>
</div>

        <label class="mr-sm-2" for="inlineFormCustomSelect">Blood Type</label>
        <select class="custom-select mr-sm-2" id="blood" name="blood">
            <option value=""><?php echo e($health->blood); ?></option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="AB">AB</option>
            <option value="O">O</option>
        </select>

         <br><br><br>

         <label for="diseases"> Do you have any Chronic diseases ?</label>
         <br>
         <input type="radio" name="diseases" value="yes" onclick="showTextBox('diseases')"
            <?php if($diseases == 'yes'): ?>
             checked
            <?php endif; ?>>Yes
             &nbsp;&nbsp;
         <input type="radio" name="diseases" value="no" onclick="hideTextBox('diseases')"
          <?php if($diseases == 'no'): ?>
            checked
            <?php endif; ?>>No
         <br><br>
         <div id="diseases-textbox" style="display:none;">
             <label for="diseases-details">If Yes, please specify:</label>
             <br>
             <textarea id="diseases-details" name="diseases_details" value ="<?php echo e($health->diseases_details); ?>" rows="4" cols="50"></textarea>
         </div>

         <br>

         <label for="surgeries">Have you had any surgeries before ?</label>
         <br>
         <input type="radio" name="surgeries" value="yes" onclick="showTextBox('surgeries')"
         <?php if($surgeries == 'yes'): ?>
         checked
         <?php endif; ?>>Yes  &nbsp;&nbsp;
         <input type="radio" name="surgeries" value="no" onclick="hideTextBox('surgeries')"
          <?php if($surgeries == 'no'): ?>
         checked
         <?php endif; ?>>No
         <br><br>
         <div id="surgeries-textbox" style="display:none;">
             <label for="surgeries-details">If Yes, please specify:</label>
             <br>
             <textarea id="surgeries-details" name="surgeries_details" value ="<?php echo e($health->surgeries_details); ?>" rows="4" cols="50"></textarea>
         </div>

         <br>
    <a >
        <button type="submit" class="btn btn-primary" style="font-size: 15px; padding: 12px 26px; display: block; margin: 0 ; float: right; "> Update </button>
    </a>
</form>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php\IDRS\resources\views/driver/edit_health.blade.php ENDPATH**/ ?>