<?php $__env->startSection('css'); ?>
<style>
    .btn:hover {
        background-color: #ffc107;
      }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
    <h2 style="text-align: center; color: blue;"> Driver Information </h2>
    <div>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
    <form action="<?php echo e(URL('update_driver')); ?>" method="POST" autocomplete="on" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-row">

            <div class="form-group col-md-6">
                <input type="hidden" name="id" value="<?php echo e($driver->id); ?>">

                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name ="name" value="<?php echo e($driver->name); ?>"  >
              </div>

          <div class="form-group col-md-6">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email"  name = "email" value="<?php echo e($driver->email); ?>" >
          </div>

          <div class="col-auto my-1">
            <label class="mr-sm-2" for="inlineFormCustomSelect">Gender</label>
            <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="gender">
                    <option ><?php echo e($driver->gender); ?></option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
            </select>
          </div>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div class="form-group">
            <label for="phone_number">Phone Number </label>
            <input type="number" class="form-control" id="phone_number"  name="phone_number" value="<?php echo e($driver->phone_number); ?>">
          </div>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


       <div class="form-group">
        <label for="city">City</label>
        <input type="text" name="city" class="form-control" id="city" value="<?php echo e($driver->city); ?>">
      </div>
         <div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

         </div>
      <div class="form-group">
        <label for="date"> Date Of Birth </label>
        <input type="date" class="form-control" id="date"  name="date_of_birth" value="<?php echo e($driver->date_of_birth); ?>">
      </div>

        <div class="form-group col-md-6">
          <label for="address">Address</label>
          <input type="text" class="form-control" id="address" name="address" value="<?php echo e($driver->address); ?>">
        </div>

        </div>

            <label class="mr-sm-2" for="inlineFormCustomSelect">Nationality</label>
            <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="nationality">
                <option ><?php echo e($driver->nationality); ?></option>
                <option value="egyptian">Egyptian</option>
                <option value="american">American</option>
                <option value="british">British</option>
                <option value="chinese">Chinese</option>
                <option value="french">French</option>
                <option value="german">German</option>
                <option value="indian">Indian</option>
                <option value="italian">Italian</option>
                <option value="japanese">Japanese</option>
                <option value="korean">Korean</option>
                <option value="mexican">Mexican</option>
                <option value="russian">Russian</option>
                <option value="spanish">Spanish</option>
            </select>

         <br><br><br>


            <label for="national_id">National-ID </label>
            <input type="number" class="form-control" id="national_id" name="national_id" value="<?php echo e($driver->national_id); ?>" >

            <div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </div>

            <label for="emergency-number">Emergency Number </label>
            <input type="number" class="form-control" id="emergency_number" name="emergency_number" value="<?php echo e($driver->emergency_number); ?>">

            <div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </div>




              <div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </div>
            <button type="submit" class="btn btn-outline-warning btn-md" style="font-size: 15px; padding: 12px 26px; display: block; margin: 0 auto;">Update</button>

            

 </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php\IDRS\resources\views/driver/edit_driver.blade.php ENDPATH**/ ?>