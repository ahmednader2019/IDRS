<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Welcome to IDRS</title>
</head>
<body style="font-family: Arial, sans-serif;">
	<h1 style="font-size: 24px; color: #2d3e50;">Welcome to IDRS</h1>
	<p style="font-size: 16px; color: #666;">Hello <strong>{{ $name }}</strong>,</p>
	<p style="font-size: 16px; color: #666;">Thank you for registering in IDRS</p>
	<p style="font-size: 16px; color: #666;">You are now user number : <strong>{{ $id }}</strong></p>
	<p style="font-size: 16px; color: #666;">Best regards,<br>The IDRS Team</p>
</body>
</html>
